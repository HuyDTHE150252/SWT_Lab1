/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package common;

/**
 *
 * @author kiennt
 */
public class AppConstant {
    public static final String ENTER_CHOICE = "Enter your choice: ";
    public static final String USER_DATA = "src/view/Data/user.dat";
}
